package project2;

import java.util.Scanner;

public class FindNthSmallestInUnionOfTwoSortedArrays {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter number of elements in the Array:-");
	    int n = scan.nextInt();
	    int[] a = new int[n];
	    int[] b = new int[n];
	    System.out.println("\nEnter "+ n +" elements of First Array A:-");
	    for (int i = 0; i < n; i++)
	        a[i] = scan.nextInt();

	    System.out.println("\nEnter "+ n +" elements of Second Array B:-");
	    for (int i = 0; i < n; i++)
		        b[i] = scan.nextInt();
	    
	    System.out.println("The nth Smallest Value of Two Sorted Array is :"+findNthSmallestInUnionOfSortedArrays(a,b,n));
	    scan.close();
	}

	public static int findNthSmallestInUnionOfSortedArrays(int[] A, int[] B, int n)
	{
		if(A[n-1] <B[0]) return A[n-1];    //if n-1th element of A is less than element of B[0] return A[n-1] element
		if(B[n-1] <A[0]) return B[n-1];    //if n-1th element of B is less than element of A[0] return B[n-1] element
		
	    int evenNumberBeforeN = n % 2 == 0 ? n : n - 1; //if n is a odd number, consider the previous even number

	    int leftHalfToSearch = evenNumberBeforeN / 2; //Consider n/2 values
	    int rightHalfToSearch = evenNumberBeforeN / 2; //Consider n/2 values
	    
	    int nBy4 = (int)Math.ceil(evenNumberBeforeN / 4.0); //Consider n/4 values
	   
	    if (nBy4 > (int)Math.ceil((n-leftHalfToSearch) / 2.0)) // take lowest value of nBy4
	        nBy4 = (int)Math.ceil((n-leftHalfToSearch) / 2.0); 

	    while(nBy4 > 0 && leftHalfToSearch < n && rightHalfToSearch < n)   // iteration nBy4 must be grater than 0 and leftHalfToSearch,rightHalfToSearch must less than n
	    {
	    	if (A[leftHalfToSearch] < B[leftHalfToSearch-1])  //compare left half of array A with left half minus 1 index of array B
	        {
	            leftHalfToSearch += nBy4;   //If the condition met Increment leftHalfToSearch by nBy4 

	            rightHalfToSearch -= nBy4;  //If the condition met decrement rightHalfToSearch by nBy4 
	        } else if (A[leftHalfToSearch-1] > B[rightHalfToSearch])  //compare left half minus 1 index of array A with left half minus 1 index of array B
	        {
	            rightHalfToSearch += nBy4;   //If the condition met Increment rightHalfToSearch by nBy4 
	            leftHalfToSearch -= nBy4;     //If the condition met decrement leftHalfToSearch by nBy4 
	        } else      //if both conditions are not true then control goes to the out of while loop
	        {
	            break;
	        }

	        nBy4 = (int)Math.ceil(nBy4/2.0); //Binary search makes the half of nBy4
	    }

	    if (evenNumberBeforeN != n)   //if evenNumberBeforeN is not equal to n
	    {
	        if (leftHalfToSearch >= n)      //if leftHalfToSearch is grater than or equal to n
	            rightHalfToSearch++;        //increment  rightHalfToSearch
	        else if (rightHalfToSearch >= n)   //if rightHalfToSearch is grater than or equal to n
	            leftHalfToSearch++;             //increment  leftHalfToSearch
	        else if (A[leftHalfToSearch] < B[rightHalfToSearch])    //if A[leftHalfToSearch] is less than B[rightHalfToSearch]
	            leftHalfToSearch++;     //increment  leftHalfToSearch
	        else
	            rightHalfToSearch++;   //increment  rightHalfToSearch
	    }
	    return A[leftHalfToSearch-1] < B[rightHalfToSearch-1] ? B[rightHalfToSearch-1] : A[leftHalfToSearch-1];
	    //if A[leftHalfToSearch-1] is less than B[rightHalfToSearch-1] then return B[rightHalfToSearch-1] else return A[leftHalfToSearch-1]
	}
}

