package project3;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

class Vertex implements Comparable<Vertex>
{
    public final String name;
    public Edge[] adjacencies;
    public double minDistance = Double.POSITIVE_INFINITY;
    public Vertex previous;
    public Vertex(String argName) { name = argName; }
    public String toString() { return name; }
    public int compareTo(Vertex other)
    {
        return Double.compare(minDistance, other.minDistance);
    }
}

class Edge
{
    public final Vertex target;
    public final double weight;
    public Edge(Vertex argTarget, double argWeight)
    { target = argTarget; weight = argWeight; }
}

public class gasStation
{
   

	public static void computePaths(Vertex source,double distToEmptyInitial,double distDrivingRange, Map<Integer, Integer> mpFuelStationVertices)
    {
		int newDistanceFulltank = 0;
        source.minDistance = 0.;
        int flag = 0;   //used flag to identify code execution first time
        PriorityQueue<Vertex> vertexQueue = new PriorityQueue<Vertex>();
      	vertexQueue.add(source);

	while (!vertexQueue.isEmpty()) {  //iterate untile vertexQueue not empty
		  if(flag == 0)// if its first vertex will add inital distance that can travel with fuel in tank to other variable
		    {
			  newDistanceFulltank += distToEmptyInitial;
		    	
		    }
		  flag = 1;// change flag status to identify we started to visist and visited first node
		  distToEmptyInitial = 0;
	    Vertex u = vertexQueue.poll();

            // Visit each edge exiting u
            for (Edge e : u.adjacencies)
            {
                Vertex v = e.target;// vertex 
                double weight = e.weight;//weight of edge 
                double distanceThroughU = u.minDistance + weight;  //add current edge weight and previously calculated weight to reach that node
              //  if(e.target == Vertex_1||vstring == "Vertex_1"||vstring == "Vertex_5")
                if( mpFuelStationVertices.values().contains(v))  //check if vertex is fuel station
    		 	{
                	newDistanceFulltank += distDrivingRange;    //add with previous distance that can travel by fuel
                	vertexQueue.remove(v);
        		    v.minDistance = distanceThroughU ;  //assign distance to mininum distance
        		    v.previous = u;   //assign curent vertex to previous vertex 
        		    vertexQueue.add(v); //add current vertex to queue
        		   
             }
                else {  // if vertex is not fule station 
                	if(distanceThroughU < v.minDistance)// select min distance
                	{
					    vertexQueue.remove(v);
					    v.minDistance = distanceThroughU ;
					    v.previous = u;
					    vertexQueue.add(v);
					 
                	}
		       }
               
               
            }
        }
    }

    public static List<Vertex> getShortestPathTo(Vertex target)
    {
        List<Vertex> path = new ArrayList<Vertex>();
        for (Vertex vertex = target; vertex != null; vertex = vertex.previous)
            path.add(vertex);
        Collections.reverse(path);
        return path; 
    }

    public static void main(String[] args) throws Exception
    {
    	//Scanner scan = new Scanner(System.in);
    	
    	Scanner scan = new Scanner(new File("/Users/vinayakjojare/Documents/workspace/gasStation/src/project3/input3.txt"));
    	
    	System.out.println("Enter the Initial driving range of the vehicle");
    	double distDrivingRange = scan.nextDouble();
    	
    	System.out.println("Enter the distance to empty from the vehicle");
    	double distToEmptyInitial = scan.nextDouble();
    	
    	System.out.println("Enter the Number of Vertices");
    	int numberOfVertices = scan.nextInt();
    	
    	System.out.println("Enter the Number of Vertices for fuel stations ");
    	int numberOfVerticesFuelStations = scan.nextInt();
    	
    	System.out.println("Enter the Vertices with Fuel Station");
    	Map<Integer, Integer> mpFuelStationVertices = new HashMap<Integer, Integer>();
    	
    	
    	
    	for(int i=0;i<numberOfVerticesFuelStations;i++){  //take input of fuel station vertices
    		int fuelStationVertices = scan.nextInt();
    		mpFuelStationVertices.put(fuelStationVertices,fuelStationVertices);
    		
    	}
    	
    	
    	
    	Vertex[] vertexArray = new Vertex[numberOfVertices];
    	for(int i=0;i<numberOfVertices;i++){
    		vertexArray[i]=new Vertex("V"+String.valueOf(i));
    	}
    	for(int i=0;i<numberOfVertices;i++){   //input for adjancies of edges
        	
    		System.out.println("Enter the adjancies for "+vertexArray[i].name);
    		Edge[] edges = new Edge[numberOfVertices];
    		for(int j=0;j<numberOfVertices;j++){  //iteration through all vertices
       			int edgeDistance = scan.nextInt();
       			int noOfEdges = 0;
       			double newDistanceToEmpty = distToEmptyInitial;
       			
       			if(mpFuelStationVertices.containsKey(i)){
       				newDistanceToEmpty = distDrivingRange;
       			}
       			if(edgeDistance>0 && (distDrivingRange >= edgeDistance) && (newDistanceToEmpty >= edgeDistance)){//check for fuel vertices and add distance of edges
       				noOfEdges++;
       				edges[j] = new Edge(vertexArray[j],edgeDistance);
       			}else{
       				edges[j] = new Edge(vertexArray[j],Double.POSITIVE_INFINITY);
       			}
       		}
    		vertexArray[i].adjacencies = edges;
       	}
    	
    	System.out.println("Enter the Source Vertex values 0 to " + String.valueOf(numberOfVertices-1));
    	int source = scan.nextInt();
    	
    	Vertex sVertex = vertexArray[source];
        computePaths(sVertex,distToEmptyInitial,distDrivingRange,mpFuelStationVertices);//function for compute shortest path
        
        System.out.println("Enter the Destination Vertex values 0 to " + String.valueOf(numberOfVertices-1));
    	int destination = scan.nextInt();
    	
    	
    	System.out.println("---------- R E S U L T -----------");
        for (Vertex v : vertexArray){
	    	if(vertexArray[destination].name.equals(v.name)){
	    		if(v.minDistance == Double.POSITIVE_INFINITY){
	    			System.err.println("You can't travel from Source to Destination");
	    		}
			    System.out.println("Distance to " + v + ": " + v.minDistance);
			    List<Vertex> path = getShortestPathTo(v);
			    System.out.println("Path: " + path);
	    	}
		}
        scan.close();
    }
}
